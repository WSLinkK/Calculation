import numpy as N
P_old=N.zeros((2,2))
print P_old

