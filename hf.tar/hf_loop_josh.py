import hf_aux
import scipy.linalg
import numpy as np
import math
from numpy import linalg as LA
def hf_loop(nao,R,nuc_rep,N):
    energyold = 0

    #--point_1_and_2---specify--integrals

    h_core_ao,v_ao,s_ao=hf_aux.get_integrals(nao)

    # h_core_ao=H_core_{mu,nu}  kinteic energy integral + nuclear-electron attraction
    # v_ao=[ij|kl] two-electron integrals Coulomb repulsion
    #--point_3--diagonalize_overlap_matrix

    X=hf_aux.calculate_S12_transformation_matrix(s_ao)

    #---point_4--guess_for_density_matrix_P_old
    #---here_you_have_to_write_it
          #---point_7_calculate_transformed--F_trans=X_transpose*F*X

    
    n_iter_max=40
    converged=False
    conv_thresh=1e-07 #threshold for convergence checking
    F=np.zeros((nao,nao))
    for iter in range(n_iter_max):
        if converged==False:
          #---point_5_prepare_G_matrix_from_equation_3.154_from_P_old_and_v_ao

          #---point_6_obtain-F=h_core+G

          #---point_7_calculate_transformed--F_trans=X_transpose*F*X

          #---here_you_have_to_write_it
          #---point_8_diagonalize--F_trans

          #-We will use a sepecial library function scipy.linalg.eigh 
          #-that performs diagonalization of a Hermitian matrix
          # epsilons are eigenvalues and C_p are eigenvectors
	#---point_9_calculate---C=X*C_p

          #---here_you_have_to_write_it
          #---point_10_form_a_new_density_matrix_(P_new)_from_3.145
          #---here_you_have_to_write_it
          #---calculate-energy--to--see--how--it--is--converging

            print(energy,"is the Hartree-Fock ground state energy.")
            print(" Energy total electronic",energy)
            print("Energy ",energy+nuc_rep," in iteration ", iter) 
            
          #--point_11_check_convergence

            if tmp_conv<=conv_thresh:
                converged=True

               # for i in range(2):
                # for j in range(2):
                 # for u in range(2):
                  # for a in range(2):
                   # H_core_MO[u,a]=H_core_MO[u,a]+C[u,i]*h_core_ao[i,j]*C[j,a]
               # for j in range(2):
                # for u in range(2):
                 # for a in range(2):
                  # H_core_MO[u,a]=H_core_MO[u,a]+C[a,j]*H_core_MO[u,j]*C[j,a]
#                print "-----In Molecular orbitals---H_core_MO=",H_core_MO
                print ("-----This was h_core_ao=",h_core_ao)
                B=np.dot(np.dot(C.T,s_ao),C)
                print(B)
            else:
                P_old[:,:]=P_new[:,:]
                energyold = energy
                print("---------Diverged----------for R=",R, "on Iteration", iter)


